self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "3c2b0b805958fab26febbd7da37cc4d9",
    "url": "/index.html"
  },
  {
    "revision": "98f8ef4044ca1d8d9702",
    "url": "/static/css/main.b1c11b79.chunk.css"
  },
  {
    "revision": "433a2800e2dcb9bd46de",
    "url": "/static/js/2.6c8c3e31.chunk.js"
  },
  {
    "revision": "99bd0487192ec9e7d9ee8fbbd91ee444",
    "url": "/static/js/2.6c8c3e31.chunk.js.LICENSE.txt"
  },
  {
    "revision": "98f8ef4044ca1d8d9702",
    "url": "/static/js/main.787e3792.chunk.js"
  },
  {
    "revision": "6e295dfcb90d4644f13b",
    "url": "/static/js/runtime-main.d1caa8f2.js"
  },
  {
    "revision": "9a4d1cc05fb3c574ef08a4c4ea0892b3",
    "url": "/static/media/add.9a4d1cc0.svg"
  },
  {
    "revision": "4e9a8934129a213612b403f752ac7dee",
    "url": "/static/media/button.4e9a8934.svg"
  },
  {
    "revision": "90acee766c4277e7ab69756d4b2a29d2",
    "url": "/static/media/delet.90acee76.svg"
  },
  {
    "revision": "fd08a111000a43e5f20de65d7276165f",
    "url": "/static/media/pause.fd08a111.svg"
  },
  {
    "revision": "949071db2c39c42535a7928254a405ff",
    "url": "/static/media/play.949071db.svg"
  },
  {
    "revision": "0e2001d96f9569ee8c93eec3782fb229",
    "url": "/static/media/select.0e2001d9.svg"
  },
  {
    "revision": "aefdd1c5c31dff7b43de0cd5c48d1158",
    "url": "/static/media/valid.aefdd1c5.svg"
  }
]);