importScripts('https://www.gstatic.com/firebasejs/4.8.1/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/4.8.1/firebase-messaging.js');

firebase.initializeApp({
    apiKey: "AIzaSyCrEgPQjewgpgLJ_eHGd0cLrwXXQ1aPnNc",
    authDomain: "pause-66b73.firebaseapp.com",
    databaseURL: "https://pause-66b73.firebaseio.com",
    projectId: "pause-66b73",
    storageBucket: "pause-66b73.appspot.com",
    messagingSenderId: "181454231342",
    appId: "1:181454231342:web:e9696e061bf36aa7f20cbf"
});

const messaging = firebase.messaging();