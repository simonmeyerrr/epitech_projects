self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "34eb98dfcdb44c0be0d85955fcdee27a",
    "url": "/index.html"
  },
  {
    "revision": "26dde4a8463a303c8cf0",
    "url": "/static/css/main.07c786f5.chunk.css"
  },
  {
    "revision": "5e3d7b43c67c792f8c67",
    "url": "/static/js/2.3594b65d.chunk.js"
  },
  {
    "revision": "7f84d11092c10d3a43893d78f68c23cb",
    "url": "/static/js/2.3594b65d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "26dde4a8463a303c8cf0",
    "url": "/static/js/main.79fdf65a.chunk.js"
  },
  {
    "revision": "6e295dfcb90d4644f13b",
    "url": "/static/js/runtime-main.d1caa8f2.js"
  },
  {
    "revision": "9a4d1cc05fb3c574ef08a4c4ea0892b3",
    "url": "/static/media/add.9a4d1cc0.svg"
  },
  {
    "revision": "4e9a8934129a213612b403f752ac7dee",
    "url": "/static/media/button.4e9a8934.svg"
  },
  {
    "revision": "90acee766c4277e7ab69756d4b2a29d2",
    "url": "/static/media/delet.90acee76.svg"
  },
  {
    "revision": "fd08a111000a43e5f20de65d7276165f",
    "url": "/static/media/pause.fd08a111.svg"
  },
  {
    "revision": "0e2001d96f9569ee8c93eec3782fb229",
    "url": "/static/media/select.0e2001d9.svg"
  },
  {
    "revision": "aefdd1c5c31dff7b43de0cd5c48d1158",
    "url": "/static/media/valid.aefdd1c5.svg"
  }
]);